import 'package:health_buddy/modals/food_modal.dart';

class ListOfFood {
  List<FoodModal> foodList;

  ListOfFood({required this.foodList});
}
